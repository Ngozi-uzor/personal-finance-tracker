
import React, { useState, useMemo } from 'react';
import { Layout } from './components/Layout';
import { Dashboard } from './components/Dashboard';
import { Transactions } from './components/Transactions';
import { Reports } from './components/Reports';
import { Auth } from './components/Auth';
import { PremiumModal } from './components/PremiumModal';

const App: React.FC = () => {
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [activeTab, setActiveTab] = useState('dashboard');
  const [isPremium, setIsPremium] = useState(false);
  const [showPremiumModal, setShowPremiumModal] = useState(false);

  const handleLogin = () => setIsAuthenticated(true);
  const handleLogout = () => setIsAuthenticated(false);
  const togglePremium = () => {
    setIsPremium(!isPremium);
    setShowPremiumModal(false);
  };

  if (!isAuthenticated) {
    return <Auth onLogin={handleLogin} />;
  }

  return (
    <div className="min-h-screen bg-gray-50 flex flex-col">
      <Layout 
        activeTab={activeTab} 
        setActiveTab={setActiveTab} 
        isPremium={isPremium} 
        onLogout={handleLogout}
        onPremiumClick={() => setShowPremiumModal(true)}
      >
        <div className="max-w-7xl mx-auto px-4 py-8 w-full">
          {activeTab === 'dashboard' && (
            <Dashboard isPremium={isPremium} onUpgrade={() => setShowPremiumModal(true)} />
          )}
          {activeTab === 'transactions' && (
            <Transactions />
          )}
          {activeTab === 'reports' && (
            <Reports isPremium={isPremium} />
          )}
        </div>
      </Layout>

      {showPremiumModal && (
        <PremiumModal 
          onClose={() => setShowPremiumModal(false)} 
          onUpgrade={togglePremium} 
        />
      )}
    </div>
  );
};

export default App;
