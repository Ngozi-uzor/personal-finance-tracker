
import React from 'react';

interface PremiumModalProps {
  onClose: () => void;
  onUpgrade: () => void;
}

export const PremiumModal: React.FC<PremiumModalProps> = ({ onClose, onUpgrade }) => {
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
      <div className="absolute inset-0 bg-gray-900/60 backdrop-blur-sm" onClick={onClose}></div>
      <div className="relative bg-white max-w-lg w-full rounded-2xl shadow-2xl overflow-hidden animate-in fade-in zoom-in duration-300">
        <button onClick={onClose} className="absolute top-4 right-4 text-gray-400 hover:text-gray-600">
          <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M6 18L18 6M6 6l12 12" /></svg>
        </button>

        <div className="p-8">
          <div className="flex flex-col items-center text-center">
            <div className="w-16 h-16 bg-amber-100 rounded-2xl flex items-center justify-center mb-6 text-3xl">🎉</div>
            <h2 className="text-3xl font-extrabold text-gray-900">Unlock Premium Features</h2>
            <p className="text-gray-500 mt-2">Go beyond income vs. expense. Master your financial future.</p>
          </div>

          <div className="mt-8 space-y-4">
            <FeatureItem title="Advanced Budget Tracking" desc="Set spending limits and get real-time alerts." />
            <FeatureItem title="Cash Flow Forecasting" desc="See your projected balance for the next 30 days." />
            <FeatureItem title="Financial Goal Setting" desc="Intelligent planning for your biggest milestones." />
            <FeatureItem title="Professional Reports" desc="Export statements for taxes and applications." />
          </div>

          <div className="mt-10 grid grid-cols-2 gap-4">
            <div className="p-4 border-2 border-gray-100 rounded-xl hover:border-indigo-100 transition-all cursor-pointer group">
              <p className="text-xs font-bold text-gray-400 uppercase">Monthly</p>
              <p className="text-2xl font-bold text-gray-900">$4.99<span className="text-sm text-gray-400">/mo</span></p>
            </div>
            <div className="p-4 border-2 border-indigo-600 rounded-xl bg-indigo-50 relative">
              <span className="absolute -top-2 left-1/2 -translate-x-1/2 bg-indigo-600 text-white text-[10px] font-bold px-2 py-0.5 rounded-full uppercase">Best Value</span>
              <p className="text-xs font-bold text-indigo-600 uppercase">Yearly (Save 40%)</p>
              <p className="text-2xl font-bold text-gray-900">$2.99<span className="text-sm text-gray-400">/mo</span></p>
            </div>
          </div>

          <button 
            onClick={onUpgrade}
            className="w-full mt-8 bg-indigo-600 text-white py-4 rounded-xl font-bold text-lg shadow-xl shadow-indigo-200 hover:bg-indigo-700 hover:-translate-y-0.5 transition-all"
          >
            Start 7-Day Free Trial
          </button>
          
          <p className="text-center text-xs text-gray-400 mt-4">Cancel anytime. Terms & conditions apply.</p>
        </div>
      </div>
    </div>
  );
};

const FeatureItem: React.FC<{ title: string, desc: string }> = ({ title, desc }) => (
  <div className="flex gap-4">
    <div className="flex-shrink-0 w-5 h-5 bg-emerald-100 text-emerald-600 rounded-full flex items-center justify-center">
      <svg className="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="3" d="M5 13l4 4L19 7" /></svg>
    </div>
    <div>
      <h4 className="text-sm font-bold text-gray-900 leading-tight">{title}</h4>
      <p className="text-sm text-gray-500 mt-0.5">{desc}</p>
    </div>
  </div>
);
