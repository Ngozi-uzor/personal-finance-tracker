
import React from 'react';
import { 
  BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, 
  PieChart, Pie, Cell, LineChart, Line, AreaChart, Area
} from 'recharts';
import { Category } from '../types';

const MOCK_MONTHLY_DATA = [
  { name: 'Jan', income: 4500, expenses: 3200 },
  { name: 'Feb', income: 5200, expenses: 2800 },
  { name: 'Mar', income: 4800, expenses: 3100 },
  { name: 'Apr', income: 6100, expenses: 2900 },
  { name: 'May', income: 5900, expenses: 3500 },
  { name: 'Jun', income: 6500, expenses: 2249 },
];

const MOCK_CATEGORIES = [
  { name: 'Food', value: 35, color: '#4F46E5' },
  { name: 'Rent', value: 25, color: '#10B981' },
  { name: 'Transport', value: 20, color: '#F59E0B' },
  { name: 'Entertainment', value: 15, color: '#EF4444' },
  { name: 'Other', value: 5, color: '#6B7280' },
];

const MOCK_GOALS = [
  { name: 'Emergency Fund', current: 3000, target: 5000, icon: '🏦' },
  { name: 'New Laptop', current: 800, target: 1200, icon: '💻' },
];

interface DashboardProps {
  isPremium: boolean;
  onUpgrade: () => void;
}

export const Dashboard: React.FC<DashboardProps> = ({ isPremium, onUpgrade }) => {
  return (
    <div className="space-y-6">
      <header className="flex justify-between items-end">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Welcome Back, Alex!</h1>
          <p className="text-gray-500 mt-1">Here's your financial summary for this month.</p>
        </div>
        <button className="bg-indigo-600 text-white px-4 py-2 rounded-lg font-semibold shadow-md hover:bg-indigo-700 transition-all flex items-center gap-2">
          <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M12 4v16m8-8H4" />
          </svg>
          Add New Transaction
        </button>
      </header>

      {/* Main Stats */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <StatCard title="BALANCE" value="$4,250.75" change="+12.5%" isPositive={true} />
        <StatCard title="INCOME" value="$6,500.00" change="+8.2%" isPositive={true} />
        <StatCard title="EXPENSES" value="$2,249.25" change="-5.3%" isPositive={false} />
      </div>

      {/* Analytics Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Spending by Category */}
        <div className="bg-white p-6 rounded-xl border border-gray-200 shadow-sm">
          <h3 className="text-lg font-bold text-gray-800 mb-4">Spending by Category</h3>
          <div className="h-64 flex flex-col md:flex-row items-center">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={MOCK_CATEGORIES}
                  innerRadius={60}
                  outerRadius={80}
                  paddingAngle={5}
                  dataKey="value"
                >
                  {MOCK_CATEGORIES.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.color} />
                  ))}
                </Pie>
                <Tooltip />
              </PieChart>
            </ResponsiveContainer>
            <div className="w-full md:w-48 mt-4 md:mt-0 space-y-2">
              {MOCK_CATEGORIES.map((cat) => (
                <div key={cat.name} className="flex items-center justify-between text-sm">
                  <div className="flex items-center gap-2">
                    <span className="w-3 h-3 rounded-full" style={{ backgroundColor: cat.color }}></span>
                    <span className="text-gray-600">{cat.name}</span>
                  </div>
                  <span className="font-semibold">{cat.value}%</span>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Budget Tracker / Premium Feature */}
        <div className={`bg-white p-6 rounded-xl border border-gray-200 shadow-sm relative overflow-hidden ${!isPremium ? 'cursor-pointer' : ''}`} onClick={!isPremium ? onUpgrade : undefined}>
          {!isPremium && (
            <div className="absolute inset-0 bg-white/60 backdrop-blur-[2px] z-10 flex flex-col items-center justify-center p-6 text-center">
              <span className="bg-amber-100 text-amber-700 px-3 py-1 rounded-full text-xs font-bold mb-3 uppercase tracking-wider">Premium Feature</span>
              <h4 className="text-xl font-bold text-gray-900 mb-2">Detailed Budget Tracker</h4>
              <p className="text-gray-600 mb-4 max-w-xs">Track spending limits and get real-time alerts when you're over budget.</p>
              <button className="bg-indigo-600 text-white px-6 py-2 rounded-lg font-bold">Unlock Now</button>
            </div>
          )}
          <h3 className="text-lg font-bold text-gray-800 mb-4">Budget Tracker</h3>
          <div className="space-y-6">
             <BudgetProgress label="Food" spent={340} limit={400} color="bg-indigo-600" />
             <BudgetProgress label="Transport" spent={240} limit={400} color="bg-emerald-500" />
             <BudgetProgress label="Entertainment" spent={276} limit={300} color="bg-amber-500" />
          </div>
        </div>
      </div>

      {/* Monthly Overview Chart */}
      <div className="bg-white p-6 rounded-xl border border-gray-200 shadow-sm">
        <div className="flex justify-between items-center mb-6">
          <h3 className="text-lg font-bold text-gray-800">Monthly Overview</h3>
          <div className="flex gap-4 text-xs font-medium uppercase tracking-wider">
            <div className="flex items-center gap-1.5"><span className="w-3 h-3 bg-indigo-600 rounded-full"></span> Income</div>
            <div className="flex items-center gap-1.5"><span className="w-3 h-3 bg-red-400 rounded-full"></span> Expenses</div>
          </div>
        </div>
        <div className="h-80 w-full">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={MOCK_MONTHLY_DATA}>
              <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
              <XAxis dataKey="name" axisLine={false} tickLine={false} tick={{fill: '#64748b', fontSize: 12}} dy={10} />
              <YAxis axisLine={false} tickLine={false} tick={{fill: '#64748b', fontSize: 12}} />
              <Tooltip cursor={{fill: '#f8fafc'}} contentStyle={{ borderRadius: '12px', border: 'none', boxShadow: '0 4px 6px -1px rgb(0 0 0 / 0.1)' }} />
              <Bar dataKey="income" fill="#4F46E5" radius={[4, 4, 0, 0]} />
              <Bar dataKey="expenses" fill="#EF4444" radius={[4, 4, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* Goals & Forecast */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="bg-white p-6 rounded-xl border border-gray-200 shadow-sm">
           <h3 className="text-lg font-bold text-gray-800 mb-4">Financial Goals</h3>
           <div className="space-y-4">
             {MOCK_GOALS.map(goal => (
               <div key={goal.name} className="p-4 border border-gray-100 rounded-lg hover:border-indigo-100 transition-colors">
                  <div className="flex justify-between items-center mb-2">
                    <div className="flex items-center gap-3">
                      <span className="text-2xl">{goal.icon}</span>
                      <span className="font-semibold text-gray-700">{goal.name}</span>
                    </div>
                    <span className="text-sm font-bold text-indigo-600">${goal.current} / ${goal.target}</span>
                  </div>
                  <div className="w-full bg-gray-100 h-2 rounded-full overflow-hidden">
                    <div 
                      className="bg-indigo-600 h-full transition-all duration-1000" 
                      style={{ width: `${(goal.current / goal.target) * 100}%` }}
                    />
                  </div>
               </div>
             ))}
           </div>
        </div>

        <div className="bg-white p-6 rounded-xl border border-gray-200 shadow-sm">
           <div className="flex justify-between items-center mb-4">
             <h3 className="text-lg font-bold text-gray-800">Cash Flow Forecast</h3>
             {isPremium && <span className="text-xs font-bold text-indigo-600 bg-indigo-50 px-2 py-1 rounded">AI Prediction</span>}
           </div>
           {!isPremium ? (
             <div className="flex flex-col items-center justify-center py-12 text-center">
                <div className="w-12 h-12 bg-indigo-100 rounded-full flex items-center justify-center mb-4">
                  <svg className="w-6 h-6 text-indigo-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M13 7h8m0 0v8m0-8l-8 8-4-4-6 6" />
                  </svg>
                </div>
                <h4 className="text-gray-900 font-bold">Forecast Your Future</h4>
                <p className="text-gray-500 text-sm mt-1 mb-4">Premium members can see their projected balances for the next 30 days.</p>
                <button onClick={onUpgrade} className="text-indigo-600 text-sm font-bold hover:underline">Learn more about Premium</button>
             </div>
           ) : (
             <div className="h-48 w-full">
               <ResponsiveContainer width="100%" height="100%">
                 <AreaChart data={MOCK_MONTHLY_DATA}>
                    <defs>
                      <linearGradient id="colorBalance" x1="0" y1="0" x2="0" y2="1">
                        <stop offset="5%" stopColor="#4F46E5" stopOpacity={0.1}/>
                        <stop offset="95%" stopColor="#4F46E5" stopOpacity={0}/>
                      </linearGradient>
                    </defs>
                    <Tooltip />
                    <Area type="monotone" dataKey="income" stroke="#4F46E5" fillOpacity={1} fill="url(#colorBalance)" />
                 </AreaChart>
               </ResponsiveContainer>
               <div className="mt-4 flex justify-between text-xs text-gray-500 font-medium">
                 <span>Current</span>
                 <span>+14 days</span>
                 <span>+30 days</span>
               </div>
             </div>
           )}
        </div>
      </div>
    </div>
  );
};

const StatCard: React.FC<{ title: string, value: string, change: string, isPositive: boolean }> = ({ title, value, change, isPositive }) => (
  <div className="bg-white p-6 rounded-xl border border-gray-200 shadow-sm hover:shadow-md transition-shadow">
    <p className="text-xs font-bold text-gray-500 uppercase tracking-widest">{title}</p>
    <div className="flex items-end justify-between mt-2">
      <h2 className="text-3xl font-bold text-gray-900">{value}</h2>
      <div className={`flex items-center text-sm font-semibold ${isPositive ? 'text-emerald-600' : 'text-rose-600'}`}>
        <svg className={`w-4 h-4 mr-0.5 ${isPositive ? '' : 'rotate-180'}`} fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M13 7h8m0 0v8m0-8l-8 8-4-4-6 6" />
        </svg>
        {change}
      </div>
    </div>
    <p className="text-xs text-gray-400 mt-1">vs last month</p>
  </div>
);

const BudgetProgress: React.FC<{ label: string, spent: number, limit: number, color: string }> = ({ label, spent, limit, color }) => (
  <div>
    <div className="flex justify-between items-end mb-2">
      <div>
        <p className="text-sm font-bold text-gray-800">{label}</p>
        <p className="text-xs text-gray-500">${limit} Budget</p>
      </div>
      <div className="text-right">
        <p className="text-sm font-bold text-gray-900">${spent} spent</p>
        <p className="text-xs text-gray-500">${limit - spent} remaining</p>
      </div>
    </div>
    <div className="w-full bg-gray-100 h-2 rounded-full overflow-hidden">
      <div 
        className={`${color} h-full transition-all duration-500`} 
        style={{ width: `${Math.min(100, (spent / limit) * 100)}%` }}
      />
    </div>
  </div>
);
