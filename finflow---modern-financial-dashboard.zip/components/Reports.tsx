
import React from 'react';

interface ReportsProps {
  isPremium: boolean;
}

export const Reports: React.FC<ReportsProps> = ({ isPremium }) => {
  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h1 className="text-3xl font-bold text-gray-900">Premium Reports</h1>
        {isPremium && (
          <button className="bg-indigo-600 text-white px-4 py-2 rounded-lg font-semibold hover:bg-indigo-700 transition-colors flex items-center gap-2">
            <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4" /></svg>
            Export All (PDF)
          </button>
        )}
      </div>

      {!isPremium ? (
        <div className="bg-white rounded-xl border-2 border-dashed border-gray-200 p-20 flex flex-col items-center justify-center text-center">
          <div className="bg-amber-100 text-amber-600 p-4 rounded-full mb-6">
            <svg className="w-12 h-12" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z" />
            </svg>
          </div>
          <h2 className="text-2xl font-bold text-gray-900">Unlock Advanced Insights</h2>
          <p className="text-gray-500 max-w-md mt-2 mb-8">
            Get deep dives into your spending trends, year-over-year comparisons, and professionally formatted income statements.
          </p>
          <button className="bg-indigo-600 text-white px-8 py-3 rounded-xl font-bold text-lg shadow-lg hover:bg-indigo-700 transition-all">
            Upgrade to Premium
          </button>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          <ReportCard 
            title="Category Deep Dive" 
            desc="Detailed analysis of where your money goes across all time."
            icon="📊"
          />
          <ReportCard 
            title="Spending Trends" 
            desc="Compare current spending to the previous year."
            icon="📈"
          />
          <ReportCard 
            title="Cash Flow Statement" 
            desc="Track money moving in and out of your accounts."
            icon="💸"
          />
          <ReportCard 
            title="Income Statement" 
            desc="Ready for tax season or loan applications."
            icon="📄"
          />
          <ReportCard 
            title="Savings Progress" 
            desc="Visual timeline of your wealth accumulation."
            icon="💰"
          />
          <ReportCard 
            title="Recurring Bills" 
            desc="Audit your subscriptions and monthly commitments."
            icon="🔄"
          />
        </div>
      )}
    </div>
  );
};

const ReportCard: React.FC<{ title: string, desc: string, icon: string }> = ({ title, desc, icon }) => (
  <div className="bg-white p-6 rounded-xl border border-gray-200 shadow-sm hover:border-indigo-300 transition-all group cursor-pointer">
    <div className="flex justify-between items-start mb-4">
      <span className="text-3xl bg-gray-50 w-12 h-12 flex items-center justify-center rounded-lg">{icon}</span>
      <button className="text-gray-400 group-hover:text-indigo-600">
        <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M12 10v6m0 0l-3-3m3 3l3-3m2 8H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" /></svg>
      </button>
    </div>
    <h3 className="text-lg font-bold text-gray-900 mb-1">{title}</h3>
    <p className="text-sm text-gray-500 leading-relaxed">{desc}</p>
  </div>
);
